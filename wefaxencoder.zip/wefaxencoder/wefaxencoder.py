#!/usr/bin/env python3
import sys
import os
import numpy as np
from PIL import Image
import scipy.io.wavfile as wav

def encode_wefax(image_path, output_wav="wefax_output.wav"):
    # Parámetros estándar de WEFAX (120 LPM)
    sample_rate = 11025  
    lpm = 120
    line_duration = 60.0 / lpm  # 0.5 segundos por línea
    samples_per_line = int(sample_rate * line_duration)
    
    # 1. Cargar y verificar la imagen
    if not os.path.exists(image_path):
        print(f"Error: No se encontró la imagen '{image_path}'")
        return

    print(f"Abriendo imagen: {image_path}")
    img = Image.open(image_path).convert('L') # Escala de grises
    width, height = img.size
    
    audio_signals = []
    
    # Función auxiliar para tonos estables
    def generate_tone(freq, duration):
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        return np.sin(2 * np.pi * freq * t)
    
    print("Sintetizando preámbulo (Tono de Inicio - 5s)...")
    # Fase 1: Inicio (Alternancia 300 Hz)
    t_start = np.linspace(0, 5, int(sample_rate * 5), endpoint=False)
    start_signal = np.sin(2 * np.pi * 1900 * t_start + 400 * np.sign(np.sin(2 * np.pi * 300 * t_start)))
    audio_signals.append(start_signal)
    
    print("Sintetizando sincronización (Fase - 20s)...")
    # Fase 2: Phasing (Pulsos blanco y negro)
    phasing_line = np.concatenate([
        generate_tone(2300, 0.025),
        generate_tone(1500, 0.475)
    ])
    for _ in range(40): # 40 líneas = 20 segundos
        audio_signals.append(phasing_line)
        
    print(f"Codificando {height} líneas de imagen...")
    # Fase 3: Imagen línea por línea
    for y in range(height):
        # Obtener píxeles de la fila actual
        line_pixels = [img.getpixel((x, y)) for x in range(width)]
        
        # Redimensionar la fila para que encaje exactamente en el tiempo de la línea
        xp = np.linspace(0, 1, width)
        x_new = np.linspace(0, 1, samples_per_line)
        interpolated_pixels = np.interp(x_new, xp, line_pixels)
        
        # Mapear brillo (0-255) a frecuencia (1500 Hz - 2300 Hz)
        frequencies = 1500 + (interpolated_pixels / 255.0) * 800
        
        # Modular en FM la fase de la portadora
        phase = 2 * np.pi * np.cumsum(frequencies) / sample_rate
        line_audio = np.sin(phase)
        audio_signals.append(line_audio)
        
    print("Sintetizando tono de parada (Stop - 5s)...")
    # Fase 4: Stop (Alternancia 450 Hz)
    t_stop = np.linspace(0, 5, int(sample_rate * 5), endpoint=False)
    stop_signal = np.sin(2 * np.pi * 1900 * t_stop + 400 * np.sign(np.sin(2 * np.pi * 450 * t_stop)))
    audio_signals.append(stop_signal)
    
    # Fase 5: Tono de cierre negro (10s)
    audio_signals.append(generate_tone(1500, 10.0))
    
    # Unir todo y guardar
    print("Generando archivo WAV...")
    full_audio = np.concatenate(audio_signals)
    full_audio = np.int16(full_audio / np.max(np.abs(full_audio)) * 32767)
    
    wav.write(output_wav, sample_rate, full_audio)
    print(f"¡Éxito total! Archivo generado: '{output_wav}'")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python wefaxencoder.py <ruta_de_la_imagen> [nombre_salida.wav]")
    else:
        imagen = sys.argv[1]
        salida = sys.argv[2] if len(sys.argv) > 2 else "wefax_output.wav"
        encode_wefax(imagen, salida)